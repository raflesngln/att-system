<?php

/*
 * ***************************************************************
 * Script : 
 * Version : 
 * Date :
 * Author : Pudyasto Adi W.
 * Email : mr.pudyasto@gmail.com
 * Description : 
 * ***************************************************************
 */

/**
 * Description of Phptable
 *
 * @author Pudyasto
 */
class Phptable extends CI_DB{
    protected $name;
    
    //put your code here
}
