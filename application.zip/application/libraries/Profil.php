<?php
class Profil{
	
	public function dataku($key){
	$nama=$key."rafles nainggolan";	
	return $nama;	
	}


}
?>