<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Track & Trace Sistem -<?php echo isset($title)?$title:'';?></title>

    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />


<style type="text/css">
	*{
		font-size: 11px;

	}
	.container{
		width: 90%;
		margin: 0px auto;
		text-align: center;
	}
	.col{ float: left; height: 150px; border:1px black solid;}
.logo{
	width: 10%;
}
.pt{ width: 20%;

}
.desc{ width: 40%;

}
.rinci{ width: 29%;

}
.col-sm{
	border: 1px black solid;
	float: left;
	height:75px;
	width: 49%;
}
.col-md{
	border:1px black solid;
	float: left;
}
.col-left{
	width: 30%;
}
.col-middle{
	width: 40%;
}
.col-right{
	width: 28%;
}
</style>

</head>
  <body>
    
 <div class="container" style="border:2px black solid;">
 <div class="row" >
    <!--LEFT INPUT-->
  <div class="col logo">      
      <div class="col-sm-12">
          <h4>&nbsp;</h4>     
          <strong><label class="col-sm-10"><h1>XSYS</h1></label></strong>
          <div class="col-sm-12">
            <p>Express Network</p>
           </div>
      </div>
  </div>
    <!--LEFT INPUT-->
  <div class="col pt">      
      <div class="col-sm-12">
          <h4>&nbsp;</h4>     
          <strong><label class="col-sm-10"><p>PT. EXPRESINDO SYSTEM NETWORK</p></label></strong>
          <div class="col-sm-12">
          <p>Perkantoran Galaxy Blok N.27</p>
          <p>Outer ringroad jaklarata barat</p>
          </div>
      </div>
  </div>

  <div class="col desc">      
      <div class="row">
      <div class="col-sm">ORIGINAL/ASAL</div>
       <div class="col-sm">DESTINATION/TUJUAN</div>
       <div class="col-sm">PIECES/JUMLAH SATUAN</div>
       <div class="col-sm">WEIGHT/BERAT</div> 
      </div>
  </div>


  <div class="col rinci">      
      <div class="col-sm-12">
          <h4>&nbsp;</h4>     
          <strong><label class="col-sm-10"><p>XXXXXXXXXXXXXXXXXXXXXXXXXXXXX</p></label></strong>
          <div class="col-sm-12">
          <p>13254535265436</p>
          </div>
      </div>
  </div>



<br style="clear:both;">
   </div>
 <div class="row">
<div class="col-md col-left">mnafkdnsfkndsk</div> 	
<div class="col-md col-middle">mnafkdnsfkndsk</div> 
<div class="col-md col-right">mnafkdnsfkndsk</div> 

 </div> 

<br style="clear:both;">
    </div>        
  </body>
</html>
