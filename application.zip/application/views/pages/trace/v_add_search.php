<form action="<?php echo base_url();?>trace/check_trace" method="post">
<div class="col-md-10">
<div class="span6 widget-container-span">
									<div class="widget-box">
									  <div class="widget-header header-color-dark">
											<h5> Track & Trace </h5>
										<div class="widget-toolbar">
												<a href="#" data-action="collapse">
													<i class="1 icon-chevron-up bigger-125"></i>
												</a>
									    </div>
									  </div>

										<div class="widget-body">
											<div class="widget-main">
												<p class="alert alert-info">
													Please input master Airwaybill/Bill landing to trace.Separate your master by coma ( , ) for multiple search</p>
												<p>
													<textarea name="code" rows="3" class="autosize-transition span12" id="form-field-11"></textarea>
											  </p>
                                              
											</div>
<div class="clearfix"></div><br />
											<div class="widget-toolbox padding-8 clearfix">
												

												<button class="btn btn-mini btn-success pull-right">
													Check this out
													<i class="icon-arrow-right icon-on-right"></i>
												</button>
											</div>
										</div>
									</div>
								</div>


</div>
</form>