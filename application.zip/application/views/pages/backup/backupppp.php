<form method="post" action="<?php echo base_url();?>master/restore" enctype="multipart/form-data">
<input type="file" name="fileku">
<input type="submit" value="restore data" class="btn btn-primary">
</form>

