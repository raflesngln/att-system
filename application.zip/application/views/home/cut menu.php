   <li> <a href="#" class="dropdown-toggle"> <i class="icon icon-strikethrough bigger-270" aria-hidden="true"></i> <span class="menu-text"> Invoice </span> <b class="arrow icon-angle-down"></b> </a>
        <ul class="submenu">
       	<li><a href="<?php echo base_url('transaksi/add_transaksi')?>"><i class="icon-exchange"></i><span class="menu-text"> Add Trans </span></a></li>        
     <li><a href="<?php echo base_url();?>transaksi/add_invoice"><i class="icon-list"></i><span class="menu-text"> Invoice </span></a></li>               
	<li><a href="<?php echo base_url();?>trace"><i class="icon-fighter-jet"></i><span class="menu-text"> Trace </span></a></li>
	
         </ul>
	  </li>
         
	<li><a href="<?php echo base_url();?>trace"><i class="icon-gear"></i><span class="menu-text"> Setting </span></a></li>
	