<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<?php
//$kode='JOB-2005201600001';
?>

<table width="200" border="1">
  <tr>
    <td>uygutgujgu</td>
    <td>gjug</td>
    <td>juguhjg</td>
    <td>jugu</td>
  </tr>
  <tr>
    <td>jghug</td>
    <td>hjug</td>
    <td>h</td>
    <td>gh</td>
  </tr>
  <tr>
    <td>gh</td>
    <td>gh</td>
    <td><?php echo $kode2;?></td>
    <td>gug</td>
  </tr>
  <tr>
    <td>ug</td>
    <td><img src="index.php/barcode/gambar/<?php echo $kode;?>" height="50" width="130"></td>
    <td>ug</td>
    <td>ug</td>
  </tr>
</table>

</body>
</html>